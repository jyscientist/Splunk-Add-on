Splunk Add-on for Blue Coat ProxySG version 3.6.0
Copyright (C) 2019 Splunk Inc. All Rights Reserved.

For documentation, see: http://docs.splunk.com/Documentation/AddOns/latest/BlueCoatProxySG
